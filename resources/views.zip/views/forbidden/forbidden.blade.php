<div class="alert alert-danger text-center mt-5" role="alert" style="max-width: 600px; margin: 0 auto;">
    <h4 class="alert-heading">Access Denied</h4>
    <p>You don't have permission to access this page. Ask your server admin for permission.</p>
    <hr>
    <p class="mb-0">If you believe this is an error, please contact support.</p>
</div>
