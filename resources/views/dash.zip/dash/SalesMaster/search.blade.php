<div class="row my-2">
				<div class="col-lg-3 mt-lg-0 mt-3">
					<div class="input-group" id="search-container">
						<input type="search" class="form-control" placeholder="Search" aria-label="Search" id="custom-search">
						<button class="btn" type="button" id="button-addon2">
							<i class="fa-solid fa-magnifying-glass"></i>
						</button>
					</div>					
				</div>
			</div>