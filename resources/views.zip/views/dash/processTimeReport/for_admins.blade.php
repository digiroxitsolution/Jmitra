<!--*******************
			Main Content start
		*******************-->
		<div class="container-fluid px-4">
			<div class="row my-5">
				<div class="col">
					<div class="border table-header p-4 position-relative rounded-top-4">
							<h5 class="text-white">Process Time Report</h5>
					</div>
					<div class="table-responsive">
						<table  id="example" class="table bg-white rounded shadow-sm table-hover">
						  <thead>
						    <tr>
						      <th scope="col">S.No. <i class="fa-solid fa-sort ms-2"></i></th>
						      <th scope="col">Employee ID <i class="fa-solid fa-sort ms-2"></i></th>
						      <th scope="col">Name <i class="fa-solid fa-sort ms-2"></i></th>
						      <th scope="col">HOD Name <i class="fa-solid fa-sort ms-2"></i></th>
						      <th scope="col">Company Name <i class="fa-solid fa-sort ms-2"></i></th>
						      <th scope="col">Location <i class="fa-solid fa-sort ms-2"></i></th>
						      <th scope="col">Expense ID <i class="fa-solid fa-sort ms-2"></i></th>
						      <th scope="col">Month of Expense <i class="fa-solid fa-sort ms-2"></i></th>
						      <th scope="col">Status <i class="fa-solid fa-sort ms-2"></i></th>
						      <th scope="col">Submission Date <i class="fa-solid fa-sort ms-2"></i></th>
						      <th scope="col">Expense Verification Date <i class="fa-solid fa-sort ms-2"></i></th>
						      <th scope="col">Expense Approved Date <i class="fa-solid fa-sort ms-2"></i></th>
						      <th scope="col">Days Elapsed (Submission) <i class="fa-solid fa-sort ms-2"></i></th>
						      <th scope="col">Days Elapsed (Verification) <i class="fa-solid fa-sort ms-2"></i></th>
						      <th scope="col">Days Elapsed (Approval) <i class="fa-solid fa-sort ms-2"></i></th>
						    </tr>
						  </thead>
						  <tbody>
						    <tr>
						      <td scope="col">01</td>
						      <td>E001</td>
						      <td>Joy</td>
						      <td>Approver</td>
						      <td>xyz</td>
						      <td>xyz</td>
						      <td>E001</td>
						      <td>August</td>
						      <td><span class="text-success">Completed</span></td>
							  <td>DD-MM-YY</td>
							  <td>DD-MM-YY</td>
							  <td>DD-MM-YY</td>
							  <td>DD-MM-YY</td>
							  <td>DD-MM-YY</td>
							  <td>DD-MM-YY</td>
						    </tr>
						  </tbody>
						</table>
					</div>
				</div>
				<!--*******************
					 Pagination Start
		 		*****************-->
					@include('includes.pagination')
				<!--*******************
					 Pagination End
		 		*****************-->
			</div>
		</div>
		<!--*******************
			Main Content End
		 *****************-->
