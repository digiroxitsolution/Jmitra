@extends('layouts.main')
@section('title', 'Dashboard | Jmitra & Co. Pvt. Ltd')
@section('content')
		
		<!--*******************
			Main Content start
		*******************-->
		<div class="container-fluid px-4">
			<div class="row g-3 mt-5">
				<div class="col-md-4 mb-md-0 mb-3">
					<div class="p-3 bg-white shadow rounded box">
						<i class="fa-solid fa-user-group shadow fs-5 rounded-3 dashboard-icon p-3"></i>
						<h5 class="text-end">Total Employee</h5>
						<h3 class="text-end">{{ $totalUsers }}</h3>
						<hr>
						<p class="text-end"><a href="{{ route('users.index') }}" class="text-decoration-none text-primary">More Info</a></p>
					</div>
				</div>

				<div class="col-md-4 mb-md-0 mb-3">
					<div class="p-3 bg-white shadow rounded box">
						<i class="fa-solid fa-user-group shadow fs-5 rounded-3 bg-primary  dashboard-icon p-3"></i>
						<h5 class="text-end">Status of Expenses</h5>
						<div class="d-flex justify-content-end rejected-completed-progress">
							<div class="me-4">
								<p class="p-0 m-0">Rejected</p>
								<p class="p-0 m-0">Completed</p>
								<p class="p-0 m-0">In Progress</p>
							</div>
							<div>
								<p class="p-0 m-0">01</p>
								<p class="p-0 m-0">01</p>
								<p class="p-0 m-0">01</p>
							</div>
						</div>
						<hr>
						<p class="text-end"><a href="statusOfExpense.html" class="text-decoration-none text-primary">More Info</a></p>
					</div>
				</div>

				<div class="col-md-4 mb-md-0 mb-3">
					<div class="p-3 bg-white shadow rounded box">
						<i class="fa-solid fa-user-group shadow fs-5 rounded-3 dashboard-icon p-3"></i>
						<h5 class="text-end">Process Time Report</h5>
						<p class="p-0 m-0 text-end">Process Name</p>
						<p class="p-0 m-0 text-end">Process Duration</p>
						<hr>
						<p class="text-end"><a href="processTimeReport.html" class="text-decoration-none text-primary">More Info</a></p>
					</div>
				</div>
			</div>
			<div class="row my-4">
				<img src="{{ asset('assets/images/superadmin-dashboard.png')}}">
			</div>
		</div>
		<!--*******************
			Main Content end
		*******************-->
	
@endsection