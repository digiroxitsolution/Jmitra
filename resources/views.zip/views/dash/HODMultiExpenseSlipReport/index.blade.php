@extends('layouts.main')
@section('title', 'Multi 
                                    Expense Slip Report| Jmitra & Co. Pvt. Ltd')
@section('content')	
<!--*******************
            Main Content start
        *******************-->
        <div class="container-fluid px-4">
            <div class="row my-5">
                <div class="col">
                    <div class="border table-header p-4 position-relative rounded-top-4">
                            <div class="d-flex justify-content-between">
                                <h5 class="text-white">Multi 
                                    Expense Slip Report</h5>
                                <button type="button" class="btn btn-warning text-white">Print</button>
                            </div>
                    </div>
                    <div class="bg-white p-4">
                        <div class="row mb-4">
                            <div class="col-lg-4 col-12">
                                <h5 class="text-muted">Your Company Name</h5>
                            </div>
                        </div>
                        <div class="row mb-4">
                            <div class="col-lg-6 col-12">
                                <label for="">Employee ID:</label>
                                <input type="text" class="form-control">
                            </div>
                            <div class="col-lg-6 col-12">
                                <label for="">Employee Name:</label>
                                <input type="text" class="form-control">
                            </div>
                        </div>
                        <div class="row mb-4">
                            <div class="col-lg-6 col-12">
                                <label for="">Month Of:</label>
                                <input type="text" class="form-control">
                            </div>
                            <div class="col-lg-6 col-12">
                                <label for="">Expense ID:</label>
                                <input type="text" class="form-control">
                            </div>
                        </div>
                        <table class="table table-bordered table-hover table-light">
                            <tbody>
                                <tr class="table-active fw-bold">
                                    <td></td>
                                    <td>Wroking Location DAYS</td>
                                    <td>Out Days</td>
                                    <td colspan="2">SUM (Rs.)</td>
                                </tr>
                                <tr>
                                    <td>DA (1-15)</td>
                                    <td>HQ Days</td>
                                    <td>Out Days</td>
                                    <td>SUM (Rs.)</td>
                                    <td><i class="fa-solid fa-trash-can bg-danger text-white p-1 rounded-circle shadow"></i></td>
                                </tr>
                                <tr>
                                    <td>DA (16-31)</td>
                                    <td>HQ Days</td>
                                    <td>Out Days</td>
                                    <td>SUM (Rs.)</td>
                                    <td><i class="fa-solid fa-trash-can bg-danger text-white p-1 rounded-circle shadow"></i></td>
                                </tr>
                                <tr>
                                    <td colspan="3" class="text-primary">Total Of DA</td>
                                    <td colspan="2"><input type="text" class="form-control"></td>
                                </tr>
                            </tbody>
                        </table>
                        <table class="table table-bordered table-hover table-light">
                            <tbody>
                                <tr class="table-active fw-bold">
                                    <td></td>
                                    <td>HQ Days</td>
                                    <td>Out Days</td>
                                    <td colspan="2">SUM (Rs.)</td>
                                </tr>
                                <tr>
                                    <td>Travel</td>
                                    <td>1-15</td>
                                    <td>16-31</td>
                                    <td>SUM (Rs.)</td>
                                    <td><i class="fa-solid fa-trash-can bg-danger text-white p-1 rounded-circle shadow"></i></td>
                                </tr>
                                <tr>
                                    <td>GENEX (Other Expenses)</td>
                                    <td>HQ Days</td>
                                    <td>Out Days</td>
                                    <td>SUM (Rs.)</td>
                                    <td><i class="fa-solid fa-trash-can bg-danger text-white p-1 rounded-circle shadow"></i></td>
                                </tr>
                                <tr>
                                    <td>POSTAGE</td>
                                    <td>HQ Days</td>
                                    <td>Out Days</td>
                                    <td>SUM (Rs.)</td>
                                    <td><i class="fa-solid fa-trash-can bg-danger text-white p-1 rounded-circle shadow"></i></td>
                                </tr>
                                <tr>
                                    <td>Mobile/ Internet</td>
                                    <td>HQ Days</td>
                                    <td>Out Days</td>
                                    <td>SUM (Rs.)</td>
                                    <td><i class="fa-solid fa-trash-can bg-danger text-white p-1 rounded-circle shadow"></i></td>
                                </tr>
                                <tr>
                                    <td>Stationery</td>
                                    <td>HQ Days</td>
                                    <td>Out Days</td>
                                    <td>SUM (Rs.)</td>
                                    <td><i class="fa-solid fa-trash-can bg-danger text-white p-1 rounded-circle shadow"></i></td>
                                </tr>
                                <tr>
                                    <td colspan="3"  class="text-primary">Total Of DA</td>
                                    <td colspan="2"><input type="text" class="form-control"></td>
                                </tr>
                                <tr>
                                    <td colspan="3"  class="text-primary">Grand Total</td>
                                    <td colspan="2"><input type="text" class="form-control"></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
                <!--*******************
                     Delete Modal Start
                *****************-->
                <div class="modal" tabindex="-1" id="deleteModal">
                  <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title">Delete</h5>
                        <button type="button" class="btn-close bg-light" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div class="modal-body">
                        <h4>Are you sure you want to delete?</h4>
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary">Yes</button>
                      </div>
                    </div>
                  </div>
                </div>
                <!--*******************
                     Delete Modal End
                *****************-->
                <!--*******************
                       Final Print Start
                *****************-->
                <div class="modal" tabindex="-1" id="printModal">
                    <div class="modal-dialog modal-dialog-centered modal-fullscreen">
                      <div class="modal-content">
                        <div class="modal-header d-flex justify-content-between">
                          <h5 class="">Final Print</h5>
                          <button type="button" class="btn btn-success"><i class="fa-solid fa-download"></i></button>
                        </div>
                        <div class="modal-body">
                            <div class="row mb-4">
                                <div class="col-lg-4 col-12">
                                    Compnay Name: xyz
                                </div>
                                <div class="col-lg-4 col-12">
                                    Division: xyz
                                </div>
                                <div class="col-lg-4 col-12">
                                    Month: xyz
                                </div>
                            </div>
                            <div class="row mb-4">
                                <div class="col-lg-4 col-12">
                                    Name: xyz
                                </div>
                                <div class="col-lg-4 col-12">
                                    Designation: xyz
                                </div>
                                <div class="col-lg-4 col-12">
                                    Location: xyz
                                </div>
                            </div>
                            <div class="row mb-4">
                                <table class="table table-bordered table-hover text-center table-light">
                                    <tbody>
                                        <tr class="table-active fw-bold">
                                            <td rowspan="2">Date</td>
                                            <td rowspan="2">From</td>
                                            <td rowspan="2">To</td>
                                            <td colspan="2">Time</td>
                                            <td rowspan="2">KM</td>
                                            <td rowspan="2">KM as per Google</td>
                                            <td rowspan="2">Mode</td>
                                            <td rowspan="2">Fare Amount</td>
                                            <td colspan="2">Daily Allowances</td>
                                            <td rowspan="2">Postage</td>
                                            <td rowspan="2">TEL/TGM</td>
                                            <td colspan="2">Other Expenses</td>
                                            <td rowspan="2">Attendace</td>
                                        </tr>
                                        <tr class="table-active fw-bold">
                                            <td>DEP</td>
                                            <td>ARR</td>
                                            <td>Working</td>
                                            <td>N. Working</td>
                                            <td>Purpose</td>
                                            <td>Amount</td>
                                        </tr>
                                        <tr>
                                            <td>1/8/24</td>
                                            <td>delhi</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td>500</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td>500</td>
                                            <td>500</td>
                                            <td class="table-active">View</td>
                                        </tr>
                                        <tr>
                                            <td>2/8/24</td>
                                            <td>delhi</td>
                                            <td></td>
                                            <td>Lalsot, Bari</td>
                                            <td></td>
                                            <td></td>
                                            <td>250</td>
                                            <td>1000</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td>Cormier</td>
                                            <td>500</td>
                                            <td class="table-active">View</td>
                                        </tr>
                                        <tr>
                                            <td>3/8/24</td>
                                            <td>delhi</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td>To</td>
                                            <td></td>
                                            <td></td>
                                            <td>500</td>
                                            <td class="table-active">View</td>
                                        </tr>
                                        <tr>
                                            <td>4/8/24</td>
                                            <td>delhi</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td>1860</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td>500</td>
                                            <td class="table-active">View</td>
                                        </tr>
                                        <tr>
                                            <td>5/8/24</td>
                                            <td>delhi</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td>380</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td>Working with<br>summer sir</td>
                                            <td>500</td>
                                            <td class="table-active">View</td>
                                        </tr>
                                        <tr>
                                            <td>6/8/24</td>
                                            <td>delhi</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td>380</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td>500</td>
                                            <td class="table-active">View</td>
                                        </tr>
                                        <tr>
                                            <td>7/8/24</td>
                                            <td>delhi</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td>380</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td>500</td>
                                            <td class="table-active">View</td>
                                        </tr>
                                        <tr>
                                            <td>8/8/24</td>
                                            <td>delhi</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td>380</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td>500</td>
                                            <td class="table-active">View</td>
                                        </tr>
                                        <tr>
                                            <td>9/8/24</td>
                                            <td>delhi</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td>380</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td>500</td>
                                            <td class="table-active">View</td>
                                        </tr>
                                        <tr>
                                            <td>10/8/24</td>
                                            <td>delhi</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td>380</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td>500</td>
                                            <td class="table-active">View</td>
                                        </tr>
                                        <tr>
                                            <td>11/8/24</td>
                                            <td>delhi</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td>380</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td>500</td>
                                            <td class="table-active">View</td>
                                        </tr>
                                        <tr>
                                            <td colspan="8"></td>
                                            <td>Total</td>
                                            <td>***</td>
                                            <td>***</td>
                                            <td>***</td>
                                            <td>***</td>
                                            <td>***</td>
                                            <td>***</td>
                                            <td>***</td>
                                        </tr>
                                        <tr>
                                            <td colspan="7"></td>
                                            <td>RUPEES in Words</td>
                                            <td colspan="4">***</td>
                                            <td>Grand Total</td>
                                            <td colspan="3">***</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div class="row mb-4">
                                <div class="col-lg-6 col-12 fw-bold">Signature of Field Staff: __________ __________ __________</div>
                                <div class="col-lg-6 col-12 fw-bold">Signature of Manager: __________ __________ __________</div>
                            </div>
                            <div class="row mb-4">
                                <div class="form-check">
                                    <input class="form-check-input me-2 ms-1" type="checkbox" value="" id="flexCheckIndeterminateAgree">
                                    <label class="form-check-label text-muted" for="flexCheckIndeterminateAgree">
                                      I hereby confirmed that I verified the Expenses and found OK as per Travel/ Daily Allowance Policy.
                                    </label>
                                  </div>
                            </div>
                            <div class="row mb-4">
                                <div class="col-lg-4 col-12">Submitted by<br>(employee name)<br>DD-MM-YY<br>HH-MM AM/PM</div>
                                <div class="col-lg-4 col-12">Verified by<br>(employee name)<br>DD-MM-YY<br>HH-MM AM/PM</div>
                                <div class="col-lg-4 col-12">Approved by<br>(employee name)<br>DD-MM-YY<br>HH-MM AM/PM</div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-success">Final Print</button>
                            <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Closed</button>
                        </div>
                      </div>
                    </div>
                  </div>
                <!--*******************
                       Final Print End
                *****************-->
                <!--*******************
                       Expense Pending Verification Edit/View Start
                *****************-->
                <div class="modal" tabindex="-1" id="expensPendingVerificationEditAndViewModal">
                    <div class="modal-dialog modal-dialog-centered modal-fullscreen">
                      <div class="modal-content">
                        <div class="modal-header d-flex justify-content-between">
                          <h5 class="">Final Print</h5>
                          <button type="button" class="btn btn-success"><i class="fa-solid fa-download"></i></button>
                        </div>
                        <div class="modal-body">
                            <div class="row mb-4">
                                <div class="col-lg-4 col-12">
                                    Compnay Name: xyz
                                </div>
                                <div class="col-lg-4 col-12">
                                    Division: xyz
                                </div>
                                <div class="col-lg-4 col-12">
                                    Month: xyz
                                </div>
                            </div>
                            <div class="row mb-4">
                                <div class="col-lg-4 col-12">
                                    Name: xyz
                                </div>
                                <div class="col-lg-4 col-12">
                                    Designation: xyz
                                </div>
                                <div class="col-lg-4 col-12">
                                    Location: xyz
                                </div>
                            </div>
                            <div class="row mb-4">
                                <table class="table table-bordered table-hover text-center table-light">
                                    <tbody>
                                        <tr class="table-active fw-bold">
                                            <td rowspan="2">Date</td>
                                            <td rowspan="2">From</td>
                                            <td rowspan="2">To</td>
                                            <td colspan="2">Time</td>
                                            <td rowspan="2">KM</td>
                                            <td rowspan="2">KM as per Google</td>
                                            <td rowspan="2">Mode</td>
                                            <td rowspan="2">Fare Amount</td>
                                            <td colspan="2">Daily Allowances</td>
                                            <td rowspan="2">Postage</td>
                                            <td rowspan="2">TEL/TGM</td>
                                            <td colspan="2">Other Expenses</td>
                                            <td rowspan="2">Attendace</td>
                                        </tr>
                                        <tr class="table-active fw-bold">
                                            <td>DEP</td>
                                            <td>ARR</td>
                                            <td>Working</td>
                                            <td>N. Working</td>
                                            <td>Purpose</td>
                                            <td>Amount</td>
                                        </tr>
                                        <tr>
                                            <td>1/8/24</td>
                                            <td>delhi</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td>500</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td>500</td>
                                            <td>500</td>
                                            <td class="table-active">View</td>
                                        </tr>
                                        <tr>
                                            <td>2/8/24</td>
                                            <td>delhi</td>
                                            <td></td>
                                            <td>Lalsot, Bari</td>
                                            <td></td>
                                            <td></td>
                                            <td class="bg-warning text-white">250</td>
                                            <td>1000</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td>Cormier</td>
                                            <td>500</td>
                                            <td class="table-active">View</td>
                                        </tr>
                                        <tr>
                                            <td>3/8/24</td>
                                            <td>delhi</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td>To</td>
                                            <td></td>
                                            <td></td>
                                            <td>500</td>
                                            <td class="table-active">View</td>
                                        </tr>
                                        <tr>
                                            <td>4/8/24</td>
                                            <td>delhi</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td>1860</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td>500</td>
                                            <td class="table-active">View</td>
                                        </tr>
                                        <tr>
                                            <td>5/8/24</td>
                                            <td>delhi</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td>380</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td>Working with<br>summer sir</td>
                                            <td>500</td>
                                            <td class="table-active">View</td>
                                        </tr>
                                        <tr>
                                            <td>6/8/24</td>
                                            <td>delhi</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td>380</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td>500</td>
                                            <td class="table-active">View</td>
                                        </tr>
                                        <tr>
                                            <td>7/8/24</td>
                                            <td>delhi</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td>380</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td>500</td>
                                            <td class="table-active">View</td>
                                        </tr>
                                        <tr>
                                            <td>8/8/24</td>
                                            <td>delhi</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td>380</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td>500</td>
                                            <td class="table-active">View</td>
                                        </tr>
                                        <tr>
                                            <td>9/8/24</td>
                                            <td>delhi</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td>380</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td>500</td>
                                            <td class="table-active">View</td>
                                        </tr>
                                        <tr>
                                            <td>10/8/24</td>
                                            <td>delhi</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td>380</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td>500</td>
                                            <td class="table-active">View</td>
                                        </tr>
                                        <tr>
                                            <td>11/8/24</td>
                                            <td>delhi</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td>380</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td>500</td>
                                            <td class="table-active">View</td>
                                        </tr>
                                        <tr>
                                            <td colspan="8"></td>
                                            <td>Total</td>
                                            <td>***</td>
                                            <td>***</td>
                                            <td>***</td>
                                            <td>***</td>
                                            <td>***</td>
                                            <td>***</td>
                                            <td>***</td>
                                        </tr>
                                        <tr>
                                            <td colspan="7"></td>
                                            <td>RUPEES in Words</td>
                                            <td colspan="4">***</td>
                                            <td>Grand Total</td>
                                            <td colspan="3">***</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div class="row mb-4">
                                <div class="col-lg-6 col-12 fw-bold">Signature of Field Staff: __________ __________ __________</div>
                                <div class="col-lg-6 col-12 fw-bold">Signature of Manager: __________ __________ __________</div>
                            </div>
                            <div class="row mb-4">
                                <div class="form-check">
                                    <input class="form-check-input me-2 ms-1" type="checkbox" value="" id="flexCheckIndeterminateAgree">
                                    <label class="form-check-label text-muted" for="flexCheckIndeterminateAgree">
                                      I hereby confirmed that I verified the Expenses and found OK as per Travel/ Daily Allowance Policy.
                                    </label>
                                  </div>
                            </div>
                            <div class="row mb-4">
                                <div class="col-lg-4 col-12">Submitted by<br>(employee name)<br>DD-MM-YY<br>HH-MM AM/PM</div>
                                <div class="col-lg-4 col-12">Verified by<br>(employee name)<br>DD-MM-YY<br>HH-MM AM/PM</div>
                                <div class="col-lg-4 col-12">Approved by<br>(employee name)<br>DD-MM-YY<br>HH-MM AM/PM</div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger">Rejected</button>
                            <button type="button" class="btn btn-warning text-white">Re-Open</button>
                            <button type="button" class="btn btn-info text-white">Save</button>
                            <button type="button" class="btn btn-success">Submit</button>
                        </div>
                      </div>
                    </div>
                  </div>
                <!--*******************
                       Expense Pending Verification Edit/View End
                *****************-->
                <!--*******************
                       Reason of Rejected Start
                *****************-->
                <div class="modal" tabindex="-1" id="reasonOfRejectedModal">
                    <div class="modal-dialog modal-dialog-centered">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title">Reason of Rejected</h5>
                          <button type="button" class="btn-close bg-light" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <label for="">Reason of Rejected</label>
                            <select class="form-select" aria-label="Default select example">
                                <option selected>Reason of Rejected</option>
                                <option value="1">Reason of Rejected 1</option>
                                <option value="2">Reason of Rejected 2</option>
                                <option value="3">Reason of Rejected 3</option>
                              </select>
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-info text-white">Save</button>
                          <button type="button" class="btn btn-success">Submit</button>
                        </div>
                      </div>
                    </div>
                  </div>
                <!--*******************
                       Reason of Rejected End
                *****************-->
                <!--*******************
                       Reason of Re-Open Start
                *****************-->
                <div class="modal" tabindex="-1" id="reasonOfReOpenModal">
                    <div class="modal-dialog modal-dialog-centered">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title">Reason of Re-Open</h5>
                          <button type="button" class="btn-close bg-light" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <label for="">Reason of Re-Open</label>
                            <select class="form-select" aria-label="Default select example">
                                <option selected>Reason of Re-Open</option>
                                <option value="1">Reason of Re-Open 1</option>
                                <option value="2">Reason of Re-Open 2</option>
                                <option value="3">Reason of Re-Open 3</option>
                              </select>
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-info text-white">Save</button>
                          <button type="button" class="btn btn-success">Submit</button>
                        </div>
                      </div>
                    </div>
                  </div>
                <!--*******************
                       Reason of Re-Open End
                *****************-->
                <!--*******************
                        Submission Promisiong Start
                *****************-->
                <div class="modal" tabindex="-1" id="submissionPromisingModal">
                    <div class="modal-dialog modal-dialog-centered">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title">Reason of Re-Open</h5>
                          <button type="button" class="btn-close bg-light" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <h6>Please Re-Check your work before Final Submission. After Final Submission you will not be able to modify it.</h6>
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-success">Final Submit</button>
                        </div>
                      </div>
                    </div>
                  </div>
                <!--*******************
                       Submission Promisiong End
                *****************-->
                <!--*******************
                     Upload File Start
                *****************-->
                 <div class="modal" tabindex="-1" id="uploadFileModal">
                    <div class="modal-dialog modal-dialog-centered modal-lg">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title">Upload File</h5>
                          <button type="button" class="btn-close bg-light" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                          <form class="p-4">
                            <div class="row mb-4">
                             <div class="col-lg-4 col-12 mb-lg-0 mb-3">
                                <input type="text" class="form-control" id="exampleInputUploadFileName" placeholder="File Name">
                             </div>
                             <div class="col-lg-6 col-12  mb-lg-0 mb-3">
                               <input type="file" class="form-control" id="exampleInputUploadFile" placeholder="Upload File">
                             </div>
                             <div class="col-lg-2 col-12">
                                <button type="button" class="btn btn-success">Download Sample</button>
                             </div>
                            </div>
                          </form>
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                          <button type="button" class="btn btn-primary">Submit</button>
                        </div>
                      </div>
                    </div>
                  </div>
                <!--*******************
                     Upload File End
                *****************-->
            </div>
        </div>
        <!--*******************
            Main Content End
         *****************-->
		

<script>
	let selectedSalesMAsterId = null;

	function loadSalesMAster(SalesMAsterId) {
	    selectedSalesMAsterId = SalesMAsterId; // Save the selected ID
	    $.ajax({
	        url: "{{ url('sales_master') }}/" + SalesMAsterId,  // Make sure this URL is correct
	        method: 'GET',
	        success: function(response) {
	            console.log('Response:', response); // Log the response for debugging
	            if (response.error) {
	                alert(response.error); // If error is returned, show an alert
	            } else {
	                // If no error, populate modal fields
	                $('#file_name').val(response.file_name); // File name
	                $('#date_of_upload').val(response.date_of_upload); // Date of upload
	                // Show the modal
	                $('#editSalesMasterModal').modal('show');
	            }
	        },
	        error: function(xhr, status, error) {
	            console.error('AJAX Error:', status, error); // Log AJAX errors
	            alert('Error fetching Sales Master.');
	        }
	    });
	}






function UpdateSalesMAster(SalesMAsterId) {
    const file_name = $('#file_name').val();
    const date_of_upload = $('#date_of_upload').val();

    // Validate inputs
    if (!file_name.trim()) {
        alert('File Name is required.');
        return;
    }

    // if (!date_of_upload.trim()) {
    //     alert('Date of Upload is required.');
    //     return;
    // }

    const data = { 
        file_name: file_name, 
        date_of_upload: date_of_upload
    };

    const token = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

    fetch("{{ url('sales_master') }}/" + SalesMAsterId, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': token,
        },
        body: JSON.stringify(data),
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        console.log(data); // Log response for debugging
        if (data.error) {
            alert(data.error);
        } else {
            alert(data.message);
            $('#editSalesMasterModal').modal('hide');
            location.reload();  // Reload the page to reflect changes
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Error updating Sales Master');
    });
}



function CreateSalesMAster() {
    const state = $('#state').val();
    const amount = $('#amount').val();
    const date = $('#date').val();

    if (!state.trim()) {
        alert('File Name is required.');
        return;
    }
    if (!amount.trim()) {
        alert('Date Of Upload is required.');
        return;
    }

    const data = { state, amount }; // Short-hand syntax
     // const data = { amount }; // Short-hand syntax
    const token = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

    fetch("{{ route('sales_master.store') }}", {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': token,
        },
        body: JSON.stringify(data),
    })
        .then(response => {
            if (!response.ok) {
                return response.text().then(html => {
                    console.error('Error HTML:', html); // Log HTML for debugging
                    throw new Error('Failed to create Sales Master.');
                });
            }
            return response.json();
        })
        .then(data => {
            alert(data.message);
            $('#addSalesMasterModal').modal('hide');
            location.reload(); // Reload the page to fetch updated data
        })
        .catch(error => {
            console.error('Error:', error.message);
            alert('Error creating Sales Master: ' + error.message);
        });
}





</script>
@endsection
