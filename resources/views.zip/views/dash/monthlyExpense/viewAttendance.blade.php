<div class="modal-dialog modal-dialog-centered modal-xl">
					  <div class="modal-content">
						<div class="modal-header">
						  <h5 class="modal-title">View of Attendance</h5>
						  <button type="button" class="btn-close bg-light" data-bs-dismiss="modal" aria-label="Close"></button>
						</div>
						<div class="modal-body">
							<table class="table table-striped table-hover">
								<thead>
								  <tr>
									<th scope="col">Name</th>
									<th scope="col">Check In Time</th>
									<th scope="col">Check Out Time</th>
									<th scope="col">Joint Purpose Details</th>
									<th scope="col">Duration</th>
									<th scope="col">Check In Address</th>
								  </tr>
								</thead>
								<tbody>
								  <tr>
									<td scope="row">xyz</td>
									<td>18 May 2024<br>05:53 PM</td>
									<td>18 May 2024<br>05:53 PM</td>
									<td>Follow up call for<br>DD1::Product Promotion</td>
									<td>21 days 2.0 hrs 44min</td>
									<td>1-Abhyankar Road, 305</td>
								  </tr>
								  <tr>
									<td scope="row">xyz</td>
									<td>18 May 2024<br>05:53 PM</td>
									<td>18 May 2024<br>05:53 PM</td>
									<td>Follow up call for<br>DD1::Product Promotion</td>
									<td>21 days 2.0 hrs 44min</td>
									<td>1-Abhyankar Road, 305</td>
								  </tr>
								</tbody>
							  </table>
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
						</div>
					  </div>
					</div>