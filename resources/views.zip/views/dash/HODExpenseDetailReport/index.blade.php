@extends('layouts.main')
@section('title', 'Expense Details Report| Jmitra & Co. Pvt. Ltd')
@section('content')	
@can('expense-details-report') 
<!--*******************
            Main Content start
        *******************-->
        <div class="container-fluid px-4">
            <div class="row my-5">
                <div class="col">
                    <div class="border table-header p-4 position-relative rounded-top-4">
                            <div class="d-flex justify-content-between">
                                <h5 class="text-white">Expense Details Report</h5>
                                <button type="button" class="btn btn-success text-light"><i class="fa-solid fa-download"></i></button>
                            </div>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover table-light">
                          <thead>
                            <tr>
                                <td colspan="8">From:</td>
                                <td colspan="14">To</td>
                            </tr>
                            <tr>
                              <th scope="col">Month</i></th>
                              <th scope="col">Company</i></th>
                              <th scope="col">State</i></th>
                              <th scope="col">Working Location</i></th>
                              <th scope="col">Name</i></th>
                              <th scope="col">Working Location_Days_1_15</i></th>
                              <th scope="col">Out_Days_1_15</i></th>
                              <th scope="col">Working Location_Days_16_31</i></th>
                              <th scope="col">Out_Days_16_31</i></th>
                              <th scope="col">Fare_1_15</i></th>
                              <th scope="col">Fare_16_31</i></th>
                              <th scope="col">GENEX</i></th>
                              <th scope="col">GENEX Remarks</i></th>
                              <th scope="col">Postage</i></th>
                              <th scope="col">Mob_Internet</i></th>
                              <th scope="col">Print_Stat</i></th>
                              <th scope="col">Fare Total</i></th>
                              <th scope="col">DA Total</i></th>
                              <th scope="col">Others</i></th>
                              <th scope="col">Total Month</i></th>
                              <th scope="col">DA_Working Location</i></th>
                              <th scope="col">DA_Out</i></th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr>
                             <td>xyz</td>
                             <td>xyz</td>
                             <td>xyz</td>
                             <td>xyz</td>
                             <td>xyz</td>
                             <td>xyz</td>
                             <td>xyz</td>
                             <td>xyz</td>
                             <td>xyz</td>
                             <td>xyz</td>
                             <td>xyz</td>
                             <td>xyz</td>
                             <td>xyz</td>
                             <td>xyz</td>
                             <td>xyz</td>
                             <td>xyz</td>
                             <td>xyz</td>
                             <td>xyz</td>
                             <td>xyz</td>
                             <td>xyz</td>
                             <td>xyz</td>
                             <td>xyz</td>
                            </tr>
                            <tr>
                                <td>xyz</td>
                                <td>xyz</td>
                                <td>xyz</td>
                                <td>xyz</td>
                                <td>xyz</td>
                                <td>xyz</td>
                                <td>xyz</td>
                                <td>xyz</td>
                                <td>xyz</td>
                                <td>xyz</td>
                                <td>xyz</td>
                                <td>xyz</td>
                                <td>xyz</td>
                                <td>xyz</td>
                                <td>xyz</td>
                                <td>xyz</td>
                                <td>xyz</td>
                                <td>xyz</td>
                                <td>xyz</td>
                                <td>xyz</td>
                                <td>xyz</td>
                                <td>xyz</td>
                            </tr>
                            <tr>
                                <td colspan="5">Total</td>
                                <td>***</td>
                                <td>***</td>
                                <td>***</td>
                                <td>***</td>
                                <td>***</td>
                                <td>***</td>
                                <td>***</td>
                                <td>***</td>
                                <td>***</td>
                                <td>***</td>
                                <td>***</td>
                                <td>***</td>
                                <td>***</td>
                                <td>***</td>
                                <td>***</td>
                            </tr>
                          </tbody>
                        </table>
                    </div>
                </div>
                <!--*******************
                     Add and Edit Modal Start
                *****************-->
                <div class="modal" tabindex="-1" id="addandeditModal">
                  <div class="modal-dialog modal-dialog-centered modal-xl">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title">Add New User</h5>
                        <button type="button" class="btn-close bg-light" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div class="modal-body">
                        <form class="p-4">
                          <div class="row mb-4">
                           <div class="col-lg-6 col-12 mb-lg-0 mb-3">
                             <label for="exampleInputName" class="form-label">Employee Name<span class="text-danger">*</span>:</label>
                             <input type="text" class="form-control" id="exampleInputName" placeholder="Employee Name">
                           </div>
                           <div class="col-lg-6 col-12">
                             <label for="exampleInputEmail" class="form-label">E-Mail:</label>
                             <input type="email" class="form-control" id="exampleInputEmail" placeholder="Email Address">
                           </div>
                          </div>
                          <div class="row mb-4">
                           <div class="col-lg-4 col-12 mb-lg-0 mb-3">
                             <label for="exampleInputPassword" class="form-label">Password<span class="text-danger">*</span>:</label>
                             <input type="password" class="form-control" id="exampleInputPassword" placeholder="Password">
                           </div>
                           <div class="col-lg-4 col-12 mb-lg-0 mb-3">
                             <label for="exampleInputPassword2" class="form-label">Confirm Password<span class="text-danger">*</span>:</label>
                             <input type="password" class="form-control" id="exampleInputPassword2" placeholder="Confirm Password">
                           </div>
                           <div class="col-lg-4 col-12 mb-lg-0">
                             <label for="exampleInputDesignation" class="form-label">Designation<span class="text-danger">*</span>:</label>
                             <select class="form-select" aria-label="Default select example" id="exampleInputDesignation">
                              <option selected>Select Designation</option>
                              <option value="1">Designation 1</option>
                              <option value="2">Designation 2</option>
                              <option value="3">Designation 3</option>
                            </select>
                           </div>
                           </div>
                           <div class="row mb-4">
                             <div class="col-lg-4 col-12 mb-lg-0 mb-3">
                                <label for="exampleInputStatus" class="form-label">Status<span class="text-danger">*</span>:</label>
                                 <select class="form-select" aria-label="Default select example" id="exampleInputStatus">
                                  <option selected>Select Status</option>
                                  <option value="1">Status 1</option>
                                  <option value="2">Status 2</option>
                                  <option value="3">Status 3</option>
                                </select>
                             </div>
                          </div>
                          <hr>
                          <div class="row mb-4">
                            <div class="col">
                                <label for="exampleInputCompanyName" class="form-label">Company Name<span class="text-danger">*</span>:</label>
                                 <select class="form-select" aria-label="Default select example" id="exampleInputCompanyName">
                                  <option selected>Select Company Name</option>
                                  <option value="1">Company Name 1</option>
                                  <option value="2">Company Name 2</option>
                                  <option value="3">Company Name 3</option>
                                </select>
                            </div>
                          </div>
                          <div class="row mb-4">
                             <div class="col-lg-4 col-12 mb-lg-0 mb-3">
                                <label for="exampleInputCity" class="form-label">City:</label>
                                 <select class="form-select" aria-label="Default select example" id="exampleInputCity">
                                  <option selected>Select City</option>
                                  <option value="1">City 1</option>
                                  <option value="2">City 2</option>
                                  <option value="3">City 3</option>
                                </select>
                             </div>
                             <div class="col-lg-4 col-12 mb-lg-0 mb-3">
                                <label for="exampleInputState" class="form-label">State<span class="text-danger">*</span>:</label>
                                 <select class="form-select" aria-label="Default select example" id="exampleInputState">
                                  <option selected>Select City</option>
                                  <option value="1">State 1</option>
                                  <option value="2">State 2</option>
                                  <option value="3">State 3</option>
                                </select>
                             </div>
                             <div class="col-lg-4 col-12 mb-lg-0">
                                <label for="exampleInputWorkingLocation" class="form-label">Working Location<span class="text-danger">*</span>:</label>
                                 <select class="form-select" aria-label="Default select example" id="exampleInputWorkingLocation">
                                  <option selected>Select Working Location</option>
                                  <option value="1">Working Location 1</option>
                                  <option value="2">Working Location 2</option>
                                  <option value="3">Working Location 3</option>
                                </select>
                             </div>
                          </div>
                          <div class="row">
                            <div class="col-lg-4 col-12 mb-lg-0 mb-3">
                                <label for="exampleInputRole" class="form-label">Role<span class="text-danger">*</span>:</label>
                                 <select class="form-select" aria-label="Default select example" id="exampleInputRole">
                                  <option selected>Select Role</option>
                                  <option value="1">Role 1</option>
                                  <option value="2">Role 2</option>
                                  <option value="3">Role 3</option>
                                </select>
                             </div>
                             <div class="col-lg-4 col-12 mb-lg-0 mb-3">
                                <label for="exampleInputHodName" class="form-label">HOD Name<span class="text-danger">*</span>:</label>
                                 <select class="form-select" aria-label="Default select example" id="exampleInputHodName">
                                  <option selected>Select Hod Name</option>
                                  <option value="1">Hod Name 1</option>
                                  <option value="2">Hod Name 2</option>
                                  <option value="3">Hod Name 3</option>
                                </select>
                             </div>
                             <div class="col-lg-4 col-12 mb-lg-0 mb-3">
                                <label for="exampleInputPolicyApplicable" class="form-label">Policy Applicable<span class="text-danger">*</span>:</label>
                                 <select class="form-select" aria-label="Default select example" id="exampleInputPolicyApplicable">
                                  <option selected>Select Policy Applicable</option>
                                  <option value="1">Policy Applicable 1</option>
                                  <option value="2">Policy Applicable 2</option>
                                  <option value="3">Policy Applicable 3</option>
                                </select>
                             </div>
                          </div>
                        </form>
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary">Add User</button>
                      </div>
                    </div>
                  </div>
                </div>
                <!--*******************
                     Add and Edit Modal End
                *****************-->
                <!--*******************
                     Delete Modal Start
                *****************-->
                <div class="modal" tabindex="-1" id="deleteModal">
                  <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title">Delete</h5>
                        <button type="button" class="btn-close bg-light" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div class="modal-body">
                        <h4>Are you sure you want to delete?</h4>
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary">Yes</button>
                      </div>
                    </div>
                  </div>
                </div>
                <!--*******************
                     Delete Modal End
                *****************-->
                <!--*******************
                     View Modal Start
                *****************-->
                <div class="modal" tabindex="-1" id="viewModal">
                  <div class="modal-dialog modal-dialog-centered modal-lg">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title">User Master</h5>
                        <button type="button" class="btn-close bg-light" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div class="modal-body">
                        <table class="table table-striped-columns">
                            <tr>
                                <td>Employee ID :</td>
                                <td>0123456789</td>
                                <td>Employee Name :</td>
                                <td>xyz</td>
                            </tr>
                            <tr class="table-group-divider">
                                <td>E-Mail :</td>
                                <td>Joe@gmail.com</td>
                                <td>Designation :</td>
                                <td>Sales & Admin</td>
                            </tr>
                            <tr>
                                <td>Status<span class="text-danger">*</span> :</td>
                                <td>Active</td>
                                <td>State<span class="text-danger">*</span>  :</td>
                                <td>Delhi</td>
                            </tr>
                            <tr>
                                <td>Company Name :</td>
                                <td>xyz</td>
                            </tr>
                            <tr>
                                <td>Working Location :</td>
                                <td>pqr</td>
                                <td>HOD Name<span class="text-danger">*</span> :</td>
                                <td>pqr</td>
                            </tr>
                            <tr>
                                <td>Role<span class="text-danger">*</span> :</td>
                                <td>xyz</td>
                                <td>Policy Applicable<span class="text-danger">*</span> :</td>
                                <td>xyz</td>
                            </tr>
                        </table>
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                      </div>
                    </div>
                  </div>
                </div>
                <!--*******************
                     View Modal End
                *****************-->
            </div>
        </div>
        <!--*******************
            Main Content End
         *****************-->
		

<script>
	let selectedSalesMAsterId = null;

	function loadSalesMAster(SalesMAsterId) {
	    selectedSalesMAsterId = SalesMAsterId; // Save the selected ID
	    $.ajax({
	        url: "{{ url('sales_master') }}/" + SalesMAsterId,  // Make sure this URL is correct
	        method: 'GET',
	        success: function(response) {
	            console.log('Response:', response); // Log the response for debugging
	            if (response.error) {
	                alert(response.error); // If error is returned, show an alert
	            } else {
	                // If no error, populate modal fields
	                $('#file_name').val(response.file_name); // File name
	                $('#date_of_upload').val(response.date_of_upload); // Date of upload
	                // Show the modal
	                $('#editSalesMasterModal').modal('show');
	            }
	        },
	        error: function(xhr, status, error) {
	            console.error('AJAX Error:', status, error); // Log AJAX errors
	            alert('Error fetching Sales Master.');
	        }
	    });
	}






function UpdateSalesMAster(SalesMAsterId) {
    const file_name = $('#file_name').val();
    const date_of_upload = $('#date_of_upload').val();

    // Validate inputs
    if (!file_name.trim()) {
        alert('File Name is required.');
        return;
    }

    // if (!date_of_upload.trim()) {
    //     alert('Date of Upload is required.');
    //     return;
    // }

    const data = { 
        file_name: file_name, 
        date_of_upload: date_of_upload
    };

    const token = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

    fetch("{{ url('sales_master') }}/" + SalesMAsterId, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': token,
        },
        body: JSON.stringify(data),
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        console.log(data); // Log response for debugging
        if (data.error) {
            alert(data.error);
        } else {
            alert(data.message);
            $('#editSalesMasterModal').modal('hide');
            location.reload();  // Reload the page to reflect changes
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Error updating Sales Master');
    });
}



function CreateSalesMAster() {
    const state = $('#state').val();
    const amount = $('#amount').val();
    const date = $('#date').val();

    if (!state.trim()) {
        alert('File Name is required.');
        return;
    }
    if (!amount.trim()) {
        alert('Date Of Upload is required.');
        return;
    }

    const data = { state, amount }; // Short-hand syntax
     // const data = { amount }; // Short-hand syntax
    const token = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

    fetch("{{ route('sales_master.store') }}", {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': token,
        },
        body: JSON.stringify(data),
    })
        .then(response => {
            if (!response.ok) {
                return response.text().then(html => {
                    console.error('Error HTML:', html); // Log HTML for debugging
                    throw new Error('Failed to create Sales Master.');
                });
            }
            return response.json();
        })
        .then(data => {
            alert(data.message);
            $('#addSalesMasterModal').modal('hide');
            location.reload(); // Reload the page to fetch updated data
        })
        .catch(error => {
            console.error('Error:', error.message);
            alert('Error creating Sales Master: ' + error.message);
        });
}





</script>
@else

@include('forbidden.forbidden')

@endcan
@endsection
