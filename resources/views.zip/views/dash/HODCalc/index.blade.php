@extends('layouts.main')
@section('title', 'HOD Calculator| Jmitra & Co. Pvt. Ltd')
@section('content')	
<!--*******************
			Main Content start
		*******************-->
		<div class="container-fluid px-4">
			<div class="row my-5">
				<div class="col-lg-6 col-12">
					<div class="border table-header p-4 position-relative rounded-top-4">
						<h5 class="text-white">Calc</h5>
					</div>
					<div class="bg-white p-4">
						<table class="table table-bordered table-hover table-light">
							<tbody>
								<tr class="table-active fw-bold">
									<th>State <i class="fa-solid fa-sort ms-2"></i></th>
									<th>Amount <i class="fa-solid fa-sort ms-2"></i></th>
								</tr>
								<tr>
									<td>654</td>
									<td>654</td>
								</tr>
							</tbody>
						</table>
					</div>
				</div>
				<div class="col-lg-6 col-12">
					<div class="border table-header p-4 position-relative rounded-top-4">
						<h5 class="text-white">State wise S/E Expense Report</h5>
					</div>
					<div class="bg-white p-4">
						<table class="table table-bordered table-hover table-light">
							<tbody>
								<tr class="table-active fw-bold">
									<th>State <i class="fa-solid fa-sort ms-2"></i></th>
									<th>Amount <i class="fa-solid fa-sort ms-2"></i></th>
								</tr>
								<tr>
									<td>654</td>
									<td>654</td>
								</tr>
							</tbody>
						</table>
					</div>
				</div>
			</div>
			<!--*******************
					 Pagination Start
		 		*****************-->
				 <div class="d-flex flex-lg-row flex-column justify-content-lg-between justify-content-center align-items-lg-start align-items-center">
					<span class="mb-lg-0 mb-3">
						<div class="d-flex flex-lg-row flex-column  align-items-center">
							<div class="me-2">
								<label for="page-size" class="form-label mb-0">Page Size:</label>
							</div>
							<div class="me-2">
								<select id="page-size" class="form-select" aria-label="Default select example">
								  <option selected>10</option>
								  <option value="20">20</option>
								  <option value="30">30</option>
								  <option value="40">40</option>
								  <option value="50">50</option>
								</select>
							</div>
							<div>
								Showing 1 to 57 of 57 entries
							</div>
						</div>
					</span>
					<nav aria-label="Page navigation example">
					  <ul class="pagination">
					    <li class="page-item">
					      <a class="page-link" href="#" aria-label="Previous">
					        <span aria-hidden="true">&laquo;</span>
					      </a>
					    </li>
					    <li class="page-item"><a class="page-link" href="#">1</a></li>
					    <li class="page-item"><a class="page-link active" href="#">2</a></li>
					    <li class="page-item"><a class="page-link" href="#">3</a></li>
					    <li class="page-item">
					      <a class="page-link" href="#" aria-label="Next">
					        <span aria-hidden="true">&raquo;</span>
					      </a>
					    </li>
					  </ul>
					</nav>
				</div>
				<!--*******************
					 Pagination End
		 		*****************-->
				<div class="row my-5">
					<div class="col-12">
						<div class="border table-header p-4 position-relative rounded-top-4">
							<h5 class="text-white">State wise S/E Expense Report</h5>
						</div>
						<div class="bg-white p-4">
							<table class="table table-bordered table-hover table-light">
								<tbody>
									<tr class="table-active fw-bold">
										<th>State <i class="fa-solid fa-sort ms-2"></i></th>
										<th>Expense <i class="fa-solid fa-sort ms-2"></i></th>
										<th>Sales <i class="fa-solid fa-sort ms-2"></i></th>
										<th>S/E <i class="fa-solid fa-sort ms-2"></i></th>
									</tr>
									<tr>
										<td>xyz</td>
										<td>xyz</td>
										<td>xyz</td>
										<td>xyz</td>
									</tr>
								</tbody>
							</table>
						</div>
					</div>
				</div>
				<!--*******************
					 Pagination Start
		 		*****************-->
				 <div class="d-flex flex-lg-row flex-column justify-content-lg-between justify-content-center align-items-lg-start align-items-center">
					<span class="mb-lg-0 mb-3">
						<div class="d-flex flex-lg-row flex-column  align-items-center">
							<div class="me-2">
								<label for="page-size" class="form-label mb-0">Page Size:</label>
							</div>
							<div class="me-2">
								<select id="page-size" class="form-select" aria-label="Default select example">
								  <option selected>10</option>
								  <option value="20">20</option>
								  <option value="30">30</option>
								  <option value="40">40</option>
								  <option value="50">50</option>
								</select>
							</div>
							<div>
								Showing 1 to 57 of 57 entries
							</div>
						</div>
					</span>
					<nav aria-label="Page navigation example">
					  <ul class="pagination">
					    <li class="page-item">
					      <a class="page-link" href="#" aria-label="Previous">
					        <span aria-hidden="true">&laquo;</span>
					      </a>
					    </li>
					    <li class="page-item"><a class="page-link" href="#">1</a></li>
					    <li class="page-item"><a class="page-link active" href="#">2</a></li>
					    <li class="page-item"><a class="page-link" href="#">3</a></li>
					    <li class="page-item">
					      <a class="page-link" href="#" aria-label="Next">
					        <span aria-hidden="true">&raquo;</span>
					      </a>
					    </li>
					  </ul>
					</nav>
				</div>
				<!--*******************
					 Pagination End
		 		*****************-->
				 <div class="row my-4">
					<img src="{{ asset('assets/calc.png') }}">
				</div>
		</div>
		<!--*******************
			Main Content End
		 *****************-->
		

<script>
	let selectedSalesMAsterId = null;

	function loadSalesMAster(SalesMAsterId) {
	    selectedSalesMAsterId = SalesMAsterId; // Save the selected ID
	    $.ajax({
	        url: "{{ url('sales_master') }}/" + SalesMAsterId,  // Make sure this URL is correct
	        method: 'GET',
	        success: function(response) {
	            console.log('Response:', response); // Log the response for debugging
	            if (response.error) {
	                alert(response.error); // If error is returned, show an alert
	            } else {
	                // If no error, populate modal fields
	                $('#file_name').val(response.file_name); // File name
	                $('#date_of_upload').val(response.date_of_upload); // Date of upload
	                // Show the modal
	                $('#editSalesMasterModal').modal('show');
	            }
	        },
	        error: function(xhr, status, error) {
	            console.error('AJAX Error:', status, error); // Log AJAX errors
	            alert('Error fetching Sales Master.');
	        }
	    });
	}






function UpdateSalesMAster(SalesMAsterId) {
    const file_name = $('#file_name').val();
    const date_of_upload = $('#date_of_upload').val();

    // Validate inputs
    if (!file_name.trim()) {
        alert('File Name is required.');
        return;
    }

    // if (!date_of_upload.trim()) {
    //     alert('Date of Upload is required.');
    //     return;
    // }

    const data = { 
        file_name: file_name, 
        date_of_upload: date_of_upload
    };

    const token = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

    fetch("{{ url('sales_master') }}/" + SalesMAsterId, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': token,
        },
        body: JSON.stringify(data),
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        console.log(data); // Log response for debugging
        if (data.error) {
            alert(data.error);
        } else {
            alert(data.message);
            $('#editSalesMasterModal').modal('hide');
            location.reload();  // Reload the page to reflect changes
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Error updating Sales Master');
    });
}



function CreateSalesMAster() {
    const state = $('#state').val();
    const amount = $('#amount').val();
    const date = $('#date').val();

    if (!state.trim()) {
        alert('File Name is required.');
        return;
    }
    if (!amount.trim()) {
        alert('Date Of Upload is required.');
        return;
    }

    const data = { state, amount }; // Short-hand syntax
     // const data = { amount }; // Short-hand syntax
    const token = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

    fetch("{{ route('sales_master.store') }}", {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': token,
        },
        body: JSON.stringify(data),
    })
        .then(response => {
            if (!response.ok) {
                return response.text().then(html => {
                    console.error('Error HTML:', html); // Log HTML for debugging
                    throw new Error('Failed to create Sales Master.');
                });
            }
            return response.json();
        })
        .then(data => {
            alert(data.message);
            $('#addSalesMasterModal').modal('hide');
            location.reload(); // Reload the page to fetch updated data
        })
        .catch(error => {
            console.error('Error:', error.message);
            alert('Error creating Sales Master: ' + error.message);
        });
}





</script>
@endsection
