@extends('layouts.main')
@section('title', 'Status Of Expenses| Jmitra & Co. Pvt. Ltd')
@section('content')	
<!--*******************
			Main Content start
		*******************-->
		<div class="container-fluid px-4">
			<div class="row g-3 my-2">
				<div class="d-grid d-flex justify-content-end">
					<a href="{{ route('status_of_expenses', ['status' => 3]) }}" class="btn add shadow me-2">
				        Rejected
				    </a>
				    <a href="{{ route('status_of_expenses', ['status' => 2]) }}" class="btn add shadow me-2">
				        In Progress
				    </a>
				    <a href="{{ route('status_of_expenses', ['status' => 1]) }}" class="btn add shadow">
				        Completed
				    </a>

					
				</div>
			</div>
				@include('includes.search')
			<div class="row my-5">
				<div class="col">
					<div class="border table-header p-4 position-relative rounded-top-4">
							<h5 class="text-white">Status of Expenses</h5>
					</div>
					<div class="table-responsive">
						<table id="example" class="table bg-white rounded shadow-sm table-hover">
						  <thead>
						    <tr>
						      <th scope="col">S.No. </th>
						      <th scope="col">Employee ID </th>
						      <th scope="col">Name </th>
						      <th scope="col">HOD Name </th>
						      <th scope="col">Company Name </th>
						      <th scope="col">Location </th>
						      <th scope="col">Expense ID </th>
						      <th scope="col">Month of Expense </th>
						      <th scope="col">Status </th>
						      <th scope="col">Reason of Rejected </th>
						      <th scope="col">Action </th>
						    </tr>
						  </thead>
							@php $i=1 @endphp
					        @foreach ($monthly_expenses as $key => $monthly_expense)
						    <tr>
						      <td scope="col">{{ $i++ }}</td>
						      <td>@if (Auth::user()->userDetail && Auth::user()->userDetail->employee_id)
	                                    {{ Auth::user()->userDetail->employee_id }}
	                                @else
	                                    N/A
	                                @endif</td>
						      <td>@if (Auth::user()->userDetail && Auth::user()->name)
	                                    {{ Auth::user()->name }}
	                                @else
	                                    N/A
	                                @endif</td>
						      <td>{{ $monthly_expense->hod->name ?? 'N/A' }}</td>
						      <td>
						      	@if (Auth::user()->userDetail && Auth::user()->userDetail->companyMaster->company_name )
	                                    {{ Auth::user()->userDetail->companyMaster->company_name  }}
		                                @else
		                                    N/A
		                                @endif
		                        </td>
						      <td>@if (Auth::user()->userDetail && Auth::user()->userDetail->locationMaster->working_location )
	                                    {{ Auth::user()->userDetail->locationMaster->working_location  }}
		                                @else
		                                    N/A
		                                @endif</td>
						      <td>{{ $monthly_expense->expense_id }}</td>
						      <td>{{ \Carbon\Carbon::parse($monthly_expense->expense_date)->format('F') }}</td>
						      <td>
								    @if ($monthly_expense->status == 3)
								        <span class="text-danger">Rejected</span>
								    @elseif ($monthly_expense->status == 2)
								        <span class="text-warning">In Progress</span>
								    @elseif ($monthly_expense->status == 1)
								        <span class="text-success">Completed</span>
								    @elseif ($monthly_expense->status == 0)
								        <span class="text-info">Not Submitted</span>
								    @endif
								</td>
						      <td>{{ \Illuminate\Support\Str::limit($monthly_expense->reason_of_rejected, 30) }}</td>
						         <td>
						      			<div class="d-flex">

					                        
					                        <span>
					                            <a href="{{ route('statement_of_expense', $monthly_expense->id) }}">
					                                <i class="fa-solid fa-eye bg-info text-white p-1 rounded-circle shadow me-2"></i>
					                            </a>
					                        </span>
					                    </div>
					            </td>
						    </tr>
						    @endforeach

						  </tbody>
						</table>
					</div>
				</div>
				<!--*******************
					 Pagination Start
		 		*****************-->
					@include('includes.pagination')
				<!--*******************
					 Pagination End
		 		*****************-->
			</div>
		</div>
		<!--*******************
			Main Content End
		 *****************-->		

<script>
	let selectedSalesMAsterId = null;

	function loadSalesMAster(SalesMAsterId) {
	    selectedSalesMAsterId = SalesMAsterId; // Save the selected ID
	    $.ajax({
	        url: "{{ url('sales_master') }}/" + SalesMAsterId,  // Make sure this URL is correct
	        method: 'GET',
	        success: function(response) {
	            console.log('Response:', response); // Log the response for debugging
	            if (response.error) {
	                alert(response.error); // If error is returned, show an alert
	            } else {
	                // If no error, populate modal fields
	                $('#file_name').val(response.file_name); // File name
	                $('#date_of_upload').val(response.date_of_upload); // Date of upload
	                // Show the modal
	                $('#editSalesMasterModal').modal('show');
	            }
	        },
	        error: function(xhr, status, error) {
	            console.error('AJAX Error:', status, error); // Log AJAX errors
	            alert('Error fetching Sales Master.');
	        }
	    });
	}






function UpdateSalesMAster(SalesMAsterId) {
    const file_name = $('#file_name').val();
    const date_of_upload = $('#date_of_upload').val();

    // Validate inputs
    if (!file_name.trim()) {
        alert('File Name is required.');
        return;
    }

    // if (!date_of_upload.trim()) {
    //     alert('Date of Upload is required.');
    //     return;
    // }

    const data = { 
        file_name: file_name, 
        date_of_upload: date_of_upload
    };

    const token = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

    fetch("{{ url('sales_master') }}/" + SalesMAsterId, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': token,
        },
        body: JSON.stringify(data),
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        console.log(data); // Log response for debugging
        if (data.error) {
            alert(data.error);
        } else {
            alert(data.message);
            $('#editSalesMasterModal').modal('hide');
            location.reload();  // Reload the page to reflect changes
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Error updating Sales Master');
    });
}



function CreateSalesMAster() {
    const state = $('#state').val();
    const amount = $('#amount').val();
    const date = $('#date').val();

    if (!state.trim()) {
        alert('File Name is required.');
        return;
    }
    if (!amount.trim()) {
        alert('Date Of Upload is required.');
        return;
    }

    const data = { state, amount }; // Short-hand syntax
     // const data = { amount }; // Short-hand syntax
    const token = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

    fetch("{{ route('sales_master.store') }}", {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': token,
        },
        body: JSON.stringify(data),
    })
        .then(response => {
            if (!response.ok) {
                return response.text().then(html => {
                    console.error('Error HTML:', html); // Log HTML for debugging
                    throw new Error('Failed to create Sales Master.');
                });
            }
            return response.json();
        })
        .then(data => {
            alert(data.message);
            $('#addSalesMasterModal').modal('hide');
            location.reload(); // Reload the page to fetch updated data
        })
        .catch(error => {
            console.error('Error:', error.message);
            alert('Error creating Sales Master: ' + error.message);
        });
}





</script>
@endsection
