
				
				  
				  	<div class="modal" tabindex="-1" id="editModal{{ $monthly_expense->id }}" tabindex="-1" aria-labelledby="editUserModalLabel{{ $monthly_expense->id }}" aria-hidden="true">
				  	<form action="{{ route('monthly_expenses.update', $monthly_expense->id) }}" method="POST">
                        @csrf
                        @method('PUT')
                    <div class="modal-dialog modal-lg modal-dialog-centered">
				    <div class="modal-content">
				      <div class="modal-header">
				        <h5 class="modal-title">Add Expenses</h5>
				        <button type="button" class="btn-close bg-light" data-bs-dismiss="modal" aria-label="Close"></button>
				      </div>
				      <div class="modal-body">
				        
                        <div class="card">
                        	<div class="card-header" style="background-color:#077fad; color:white;">
							    EXenses
							  </div>
							  <div class="card-body">
								  <div class="row mb-4">
								   
								   <div class="col-lg-6 col-12">
								   	 <label for="expense_date" class="form-label">Expense Date<span class="text-danger">*</span>:</label>
									 <input type="date" class="form-control" id="expense_date" name="expense_date" placeholder="Expense Date" value="{{ \Carbon\Carbon::parse($monthly_expense->expense_date)->format('Y-m-d') }}">
								   </div>
								   <div class="col-lg-6 col-12">
								   	 <label for="expense_type_master_id" class="form-label">Expense Type<span class="text-danger">*</span>:</label>
									 <select class="form-select" aria-label="Default select example" id="expense_type_master_id" name="expense_type_master_id">
									    <option value="" disabled selected>Select Expense Type</option>
									    @foreach ($expense_type_master as $expense_type)
									        <option value="{{ $expense_type->id }}" {{ $expense_type->id == $monthly_expense->expense_type_master_id ? 'selected' : '' }}>
									            {{ $expense_type->expense_type }}
									        </option>
									    @endforeach
									</select>
																	   </div>
								  </div>
								  <div class="row mb-4">
								    <div class="col-lg-6 col-12 mb-lg-0 mb-3">
										<label for="one_way_two_way_multi_location" class="form-label">One Way/ Two Way/ Multi Location<span class="text-danger">*</span>:</label>
										<select class="form-select" aria-label="Default select example" id="one_way_two_way_multi_location" name="one_way_two_way_multi_location">
										<option value="One Way" {{ $monthly_expense->one_way_two_way_multi_location === 'One Way' ? 'selected' : '' }}>One Way</option>
									    <option value="Two Way" {{ $monthly_expense->one_way_two_way_multi_location === 'Two Way' ? 'selected' : '' }}>Two Way</option>
									    <option value="Multi Location" {{ $monthly_expense->one_way_two_way_multi_location === 'Multi Location' ? 'selected' : '' }}>Multi Location</option>
										</select>
									</div>
									<div class="col-lg-6 col-12 mb-lg-0 mb-3">
										<label for="from" class="form-label">From<span class="text-danger">*</span>:</label>
										<input type="text" class="form-control" id="from" name="from" placeholder="From" value="{{ $monthly_expense->from }}">
									</div>
								   </div>
								   <div class="row mb-4">
									<div class="col-lg-6 col-12 mb-lg-0 mb-3">
										<label for="to" class="form-label">To<span class="text-danger">*</span>:</label>
										<input type="text" class="form-control" id="to" name="to" placeholder="To" value="{{ $monthly_expense->to }}">
									</div>
									<div class="col-lg-6 col-12 mb-lg-0 mb-3">
										<label for="departure_time" class="form-label">Dep. Time:</label>
										<input type="datetime-local" class="form-control" id="departure_time" name="departure_time" placeholder="Dep. Time" value="{{ $monthly_expense->departure_time }}">
									</div>
								  </div>
								  <div class="row mb-4">
									<div class="col-lg-6 col-12 mb-lg-0 mb-3">
										<label for="arrival_time" class="form-label">Arr. Time:</label>
										<input type="datetime-local" class="form-control" id="arrival_time" name="arrival_time" placeholder="Arr. Time" value="{{ $monthly_expense->arrival_time }}">
									</div>
									<div class="col-lg-6 col-12 mb-lg-0 mb-3">
										<label for="km_as_per_user" class="form-label">KM. as per User<span class="text-danger">*</span></label>
										<input type="number" class="form-control" id="km_as_per_user" name="km_as_per_user" placeholder="KM. as per User" value="{{ $monthly_expense->km_as_per_user }}">
									</div>
								  </div>
								  <div class="row mb-4">
									<div class="col-lg-6 col-12 mb-lg-0 mb-3">
										<label for="km_as_per_google_map" class="form-label">KM. as per Google Map:<span class="text-danger">*</span></label>
										<input type="number" class="form-control" id="km_as_per_google_map" name="km_as_per_google_map" placeholder="KM. as per Google Map" value="{{ $monthly_expense->km_as_per_google_map }}">
									</div>
									<div class="col-lg-6 col-12 mb-lg-0 mb-3">
										<label for="mode_of_expense_master_id" class="form-label">Expense Mode:<span class="text-danger">*</span></label>
										<select class="form-select" aria-label="Default select example" id="mode_of_expense_master_id" name="mode_of_expense_master_id">
											<option value="" disabled selected>Select Expense Mode</option>
											@foreach($expense_modes as $expense_mode)
		                                            <option value="{{ $expense_mode->id }}" {{ $expense_mode->id == $monthly_expense->mode_of_expense_master_id ? 'selected' : '' }}>
		                                                {{ $expense_mode->mode_expense }}
		                                            </option>
		                                        @endforeach
											</select>
									</div>
								  </div>
								  <div class="row">
									<div class="col-lg-6 col-12 mb-lg-0 mb-3">
										<label for="fare_amount" class="form-label">Fare Amount:<span class="text-danger">*</span></label>
										<input type="number" class="form-control" id="fare_amount" name="fare_amount" placeholder="Fare Amount" value="{{ $monthly_expense->fare_amount }}">
									</div>
									<div class="col-lg-6 col-12 mb-lg-0 mb-3">
										<label for="da_location" class="form-label">DA(Location):</label>
										<input type="number" class="form-control" id="da_location" name="da_location" placeholder="DA(Location)" value="{{ $monthly_expense->da_location }}">
									</div>
								  </div>
								</div>
						  </div>



						  <hr>
						  <div class="card">
                        	<div class="card-header" style="background-color:#077fad; color:white;">
							    Monthly Expenses
							  </div>
							  <div class="card-body">
								  <div class="row mb-4">
									 <div class="col-lg-6 col-12 mb-lg-0 mb-3">
										  <label for="da_ex_location" class="form-label">DA(Ex-Location):</label>
									   <input type="number" class="form-control" id="da_ex_location" name="da_ex_location" placeholder="DA(Ex-Location)" value="{{ $monthly_expense->da_ex_location }}">
									 </div>
									 <div class="col-lg-6 col-12">
										  <label for="da_outstation" class="form-label">DA(Outstation)<span class="text-danger">*</span>:</label>
									   <input type="number" class="form-control" id="da_outstation" name="da_outstation" placeholder="DA(Outstation)" value="{{ $monthly_expense->da_outstation }}">
									 </div>
									</div>
									<div class="row mb-4">
										<div class="col-lg-6 col-12 mb-lg-0 mb-3">
											<label for="da_total" class="form-label">DA(Total)<span class="text-danger">*</span>:</label>
										 <input type="number" class="form-control" id="da_total" name="da_total" placeholder="DA(Total)" value="{{ $monthly_expense->da_total }}">
									  	 </div>
										<div class="col-lg-6 col-12">
												<label for="postage" class="form-label">Postage<span class="text-danger">*</span>:</label>
											<input type="number" class="form-control" id="postage" name="postage" placeholder="Postage" value="{{ $monthly_expense->postage }}">
										</div>
									 </div>
									 <div class="row mb-4">
										<div class="col-lg-6 col-12 mb-lg-0 mb-3">
											<label for="mobile_internet" class="form-label">Mobile/Internet<span class="text-danger">*</span>:</label>
										 <input type="number" class="form-control" id="mobile_internet" name="mobile_internet" placeholder="Mobile/Internet" value="{{ $monthly_expense->mobile_internet }}">
									  	 </div>
										<div class="col-lg-6 col-12">
												<label for="print_stationery" class="form-label">Print Stationery<span class="text-danger">*</span>:</label>
											<input type="number" class="form-control" id="print_stationery" name="print_stationery" placeholder="Print_Stationery" value="{{ $monthly_expense->print_stationery }}">
										</div>
									</div>
									<div class="row mb-4">
										<div class="col-lg-6 col-12 mb-lg-0 mb-3">
											<label for="other_expense_master_id" class="form-label">Other Expenses Purpose<span class="text-danger">*</span>:</label>
											<select class="form-select" aria-label="Default select example" id="other_expense_master_id" name="other_expense_master_id">
												<option value="" disabled selected>Select Other Expenses Purpose</option>

												@foreach($other_expense_master as $other_expense)
		                                            <option value="{{ $other_expense->id }}" {{ $other_expense->id == $monthly_expense->other_expense_master_id ? 'selected' : '' }}>
		                                                {{ $other_expense->other_expense }}
		                                            </option>
		                                        @endforeach
												
												</select>
									  	 </div>
										<div class="col-lg-6 col-12">
												<label for="other_expenses_amount" class="form-label">Other Expenses Amount<span class="text-danger">*</span>:</label>
											<input type="number" class="form-control" id="other_expenses_amount" name="other_expenses_amount" placeholder="Other Expenses Amount" value="{{ $monthly_expense->other_expenses_amount }}">
										</div>
									</div>
									<div class="row mb-4">
										<div class="col-6">
											<div class="row">
											    <label class="mb-1">Pre-Approved<span class="text-danger">*</span>:</label>
											    <div class="col-lg-2 col-12 mb-lg-0 mb-3">
											        <input class="form-check-input" type="radio" name="pre_approved" id="pre_approved_yes" value="Yes" 
											            @if($monthly_expense->pre_approved == 'Yes') checked @endif>
											        <label class="form-check-label" for="pre_approved_yes">Yes</label>
											    </div>
											    <div class="col-lg-2 col-12 mb-lg-0 mb-3">
											        <input class="form-check-input" type="radio" name="pre_approved" id="pre_approved_no" value="No" 
											            @if($monthly_expense->pre_approved == 'No') checked @endif>
											        <label class="form-check-label" for="pre_approved_no">No</label>
											    </div>
											    <div class="col-lg-2 col-12 mb-lg-0 mb-3">
											        <input class="form-check-input" type="radio" name="pre_approved" id="pre_approved_na" value="N.A" 
											            @if($monthly_expense->pre_approved == 'N.A') checked @endif>
											        <label class="form-check-label" for="pre_approved_na">N.A.</label>
											    </div>
											</div>
										</div>
										<div class="col-6">
											<div class="row">
												<div class="d-flex justify-content-between">
													<div>
														<label class="mb-1">Approved Date<span class="text-danger">*</span>:</label>
													</div>
													<div>
														<label for="ApprovedDate">Date<span class="text-danger">*</span>:</label>
													</div>
												</div>
												<div class="col-lg-4 col-12 mb-lg-0 mb-3">
													<label class="form-check-label" for="inlineRadioOptionsApprovedDate1">Date</label>
													<input class="form-check-input" type="radio" name="inlineRadioOptionsApprovedDate" id="" name="" value="option1">
												</div>
												<div class="col-lg-4 col-12 mb-lg-0 mb-3">
													<label class="form-check-label" for="inlineRadioOptionsApprovedDate2">N.A.</label>
												  <input class="form-check-input" type="radio" name="inlineRadioOptionsApprovedDate" id="" name="" value="option2">
												</div>
												<div class="col-lg-4 col-12 mb-lg-0 mb-3">
													<input type="date" id="approved_date" name="approved_date" class="form-control" value="{{ $monthly_expense->approved_date }}"> 
												</div>
											</div>
										</div>
									</div>
									<div class="row mb-4">
										<div class="col-lg-6 col-12 mb-lg-0 mb-3">
											<label for="approved_by" class="form-label">Approved By<span class="text-danger">*</span>:</label>
											<select class="form-select" aria-label="Default select example" id="approved_by" name="approved_by">
											<option value="" disabled selected>Select Aproved By</option>
												@foreach($users as $user)
		                                            <option value="{{ $user->id }}" {{ $user->id == $monthly_expense->approved_by ? 'selected' : '' }}>
		                                                {{ $user->name }}
		                                            </option>
		                                        @endforeach
											</select>
										</div>
										<div class="col-6">
											<div class="row">
												<label class="mb-1">Upload of Approvals Documnets<span class="text-danger">*</span>:</label>
												<div class="col-lg-3 col-12 mb-lg-0 mb-3">
													<label class="form-check-label" for="inlineRadioOptionsUploadOfApprovalsDocumentsUpload">Upload</label>
													<input class="form-check-input" type="radio" name="inlineRadioOptionsUploadOfApprovalsDocuments" id="inlineRadioOptionsUploadOfApprovalsDocuments" value="option1">
												</div>
												<div class="col-lg-2 col-12 mb-lg-0 mb-3">
													<label class="form-check-label" for="inlineRadioOptionsUploadOfApprovalsDocumentsNA">N.A.</label>
													<input class="form-check-input" type="radio" name="inlineRadioOptionsUploadOfApprovalsDocuments" id="inlineRadioOptionsUploadOfApprovalsDocumentsNA" value="option2">
												</div>
												<div class="col-lg-7 col-12 mb-lg-0 mb-3">
													<input class="form-control" type="file" id="" name="">
												</div>
											</div>
										</div>
									</div>
									<div class="row mb-4">
										<div class="col-6">
											<label class="mb-1"  >View of Attendace <span class="text-danger">*</span></label><br>
											<button data-bs-toggle="modal" data-bs-target="#viewOfAttendenceModal" type="button" class="btn btn-success">View</button>
										</div>
										<div class="col-6">
											<label for="remarks">Remarks <span class="text-danger">*</span></label>
											<input type="text" class="form-control" id="remarks" name="remarks" value="{{ $monthly_expense->remarks }}">
										</div>
									</div>
									<div class="row mb-4">
										<div class="col-12">
											<input class="form-check-input me-2" type="checkbox" value="1" id="accept_policy" name="accept_policy" {{ $monthly_expense->accept_policy == 1 ? 'checked' : '' }}>

											<label class="form-check-label" for="accept_policy">I hereby confirmed that I have verify the Expenses and found OK as per Travel/ Daily Allowance Policy.</label>
										</div>
									</div>

								
						      </div>
						      <div class="modal-footer">
						        <button type="submit" class="btn btn-success">Submit</button>
						      </div>
						    </div>
						    </form>
						  </div>
						</div>
					 </div>

				
				